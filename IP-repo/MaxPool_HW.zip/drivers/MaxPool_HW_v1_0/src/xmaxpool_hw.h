// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XMAXPOOL_HW_H
#define XMAXPOOL_HW_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xmaxpool_hw_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XMaxpool_hw_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XMaxpool_hw;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XMaxpool_hw_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XMaxpool_hw_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XMaxpool_hw_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XMaxpool_hw_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XMaxpool_hw_Initialize(XMaxpool_hw *InstancePtr, u16 DeviceId);
XMaxpool_hw_Config* XMaxpool_hw_LookupConfig(u16 DeviceId);
int XMaxpool_hw_CfgInitialize(XMaxpool_hw *InstancePtr, XMaxpool_hw_Config *ConfigPtr);
#else
int XMaxpool_hw_Initialize(XMaxpool_hw *InstancePtr, const char* InstanceName);
int XMaxpool_hw_Release(XMaxpool_hw *InstancePtr);
#endif

void XMaxpool_hw_Start(XMaxpool_hw *InstancePtr);
u32 XMaxpool_hw_IsDone(XMaxpool_hw *InstancePtr);
u32 XMaxpool_hw_IsIdle(XMaxpool_hw *InstancePtr);
u32 XMaxpool_hw_IsReady(XMaxpool_hw *InstancePtr);
void XMaxpool_hw_EnableAutoRestart(XMaxpool_hw *InstancePtr);
void XMaxpool_hw_DisableAutoRestart(XMaxpool_hw *InstancePtr);

void XMaxpool_hw_Set_input_r(XMaxpool_hw *InstancePtr, u32 Data);
u32 XMaxpool_hw_Get_input_r(XMaxpool_hw *InstancePtr);
void XMaxpool_hw_Set_output_r(XMaxpool_hw *InstancePtr, u32 Data);
u32 XMaxpool_hw_Get_output_r(XMaxpool_hw *InstancePtr);
void XMaxpool_hw_Set_channels(XMaxpool_hw *InstancePtr, u32 Data);
u32 XMaxpool_hw_Get_channels(XMaxpool_hw *InstancePtr);
void XMaxpool_hw_Set_width(XMaxpool_hw *InstancePtr, u32 Data);
u32 XMaxpool_hw_Get_width(XMaxpool_hw *InstancePtr);
void XMaxpool_hw_Set_height(XMaxpool_hw *InstancePtr, u32 Data);
u32 XMaxpool_hw_Get_height(XMaxpool_hw *InstancePtr);

void XMaxpool_hw_InterruptGlobalEnable(XMaxpool_hw *InstancePtr);
void XMaxpool_hw_InterruptGlobalDisable(XMaxpool_hw *InstancePtr);
void XMaxpool_hw_InterruptEnable(XMaxpool_hw *InstancePtr, u32 Mask);
void XMaxpool_hw_InterruptDisable(XMaxpool_hw *InstancePtr, u32 Mask);
void XMaxpool_hw_InterruptClear(XMaxpool_hw *InstancePtr, u32 Mask);
u32 XMaxpool_hw_InterruptGetEnabled(XMaxpool_hw *InstancePtr);
u32 XMaxpool_hw_InterruptGetStatus(XMaxpool_hw *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
