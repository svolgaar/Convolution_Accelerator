// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xmaxpool_hw.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XMaxpool_hw_CfgInitialize(XMaxpool_hw *InstancePtr, XMaxpool_hw_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XMaxpool_hw_Start(XMaxpool_hw *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMaxpool_hw_ReadReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_AP_CTRL) & 0x80;
    XMaxpool_hw_WriteReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XMaxpool_hw_IsDone(XMaxpool_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMaxpool_hw_ReadReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XMaxpool_hw_IsIdle(XMaxpool_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMaxpool_hw_ReadReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XMaxpool_hw_IsReady(XMaxpool_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMaxpool_hw_ReadReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XMaxpool_hw_EnableAutoRestart(XMaxpool_hw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMaxpool_hw_WriteReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XMaxpool_hw_DisableAutoRestart(XMaxpool_hw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMaxpool_hw_WriteReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_AP_CTRL, 0);
}

void XMaxpool_hw_Set_input_r(XMaxpool_hw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMaxpool_hw_WriteReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_INPUT_R_DATA, Data);
}

u32 XMaxpool_hw_Get_input_r(XMaxpool_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMaxpool_hw_ReadReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_INPUT_R_DATA);
    return Data;
}

void XMaxpool_hw_Set_output_r(XMaxpool_hw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMaxpool_hw_WriteReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_OUTPUT_R_DATA, Data);
}

u32 XMaxpool_hw_Get_output_r(XMaxpool_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMaxpool_hw_ReadReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_OUTPUT_R_DATA);
    return Data;
}

void XMaxpool_hw_Set_channels(XMaxpool_hw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMaxpool_hw_WriteReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_CHANNELS_DATA, Data);
}

u32 XMaxpool_hw_Get_channels(XMaxpool_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMaxpool_hw_ReadReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_CHANNELS_DATA);
    return Data;
}

void XMaxpool_hw_Set_width(XMaxpool_hw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMaxpool_hw_WriteReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_WIDTH_DATA, Data);
}

u32 XMaxpool_hw_Get_width(XMaxpool_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMaxpool_hw_ReadReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_WIDTH_DATA);
    return Data;
}

void XMaxpool_hw_Set_height(XMaxpool_hw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMaxpool_hw_WriteReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_HEIGHT_DATA, Data);
}

u32 XMaxpool_hw_Get_height(XMaxpool_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMaxpool_hw_ReadReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_HEIGHT_DATA);
    return Data;
}

void XMaxpool_hw_InterruptGlobalEnable(XMaxpool_hw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMaxpool_hw_WriteReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_GIE, 1);
}

void XMaxpool_hw_InterruptGlobalDisable(XMaxpool_hw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMaxpool_hw_WriteReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_GIE, 0);
}

void XMaxpool_hw_InterruptEnable(XMaxpool_hw *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMaxpool_hw_ReadReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_IER);
    XMaxpool_hw_WriteReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_IER, Register | Mask);
}

void XMaxpool_hw_InterruptDisable(XMaxpool_hw *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMaxpool_hw_ReadReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_IER);
    XMaxpool_hw_WriteReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_IER, Register & (~Mask));
}

void XMaxpool_hw_InterruptClear(XMaxpool_hw *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMaxpool_hw_WriteReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_ISR, Mask);
}

u32 XMaxpool_hw_InterruptGetEnabled(XMaxpool_hw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMaxpool_hw_ReadReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_IER);
}

u32 XMaxpool_hw_InterruptGetStatus(XMaxpool_hw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMaxpool_hw_ReadReg(InstancePtr->Control_BaseAddress, XMAXPOOL_HW_CONTROL_ADDR_ISR);
}

