// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xmaxpool_hw.h"

extern XMaxpool_hw_Config XMaxpool_hw_ConfigTable[];

XMaxpool_hw_Config *XMaxpool_hw_LookupConfig(u16 DeviceId) {
	XMaxpool_hw_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XMAXPOOL_HW_NUM_INSTANCES; Index++) {
		if (XMaxpool_hw_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XMaxpool_hw_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMaxpool_hw_Initialize(XMaxpool_hw *InstancePtr, u16 DeviceId) {
	XMaxpool_hw_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMaxpool_hw_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMaxpool_hw_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

